# WebAppDR
Simple WebApp with CD

Demo de CD con GitHub Actions y Azure almacenando imagenes en un blob storage con un saas

![ds2](https://user-images.githubusercontent.com/9124597/118070130-f39d2700-b36a-11eb-9e95-6bdcc53e52b7.PNG)

![image](https://user-images.githubusercontent.com/9124597/118071338-34963b00-b36d-11eb-9b34-c38c590f82c5.png)

![DS3](https://user-images.githubusercontent.com/9124597/118071514-8a6ae300-b36d-11eb-8203-6cf48af15a8d.png)
